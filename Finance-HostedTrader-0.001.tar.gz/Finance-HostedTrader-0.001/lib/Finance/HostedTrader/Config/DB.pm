package Finance::HostedTrader::Config::DB;
# ABSTRACT: Finance::HostedTrader::Config::DB - DB Configuration for the Finance::HostedTrader platform


use strict;
use warnings;
use Moose;

has dbhost => (
    is     => 'ro',
    isa    => 'Str',
    required=>1,
);


has dbname => (
    is     => 'ro',
    isa    => 'Str',
    required=>1,
);


has dbuser => (
    is     => 'ro',
    isa    => 'Str',
    required=>1,
);


has dbpasswd => (
    is     => 'ro',
    isa    => 'Maybe[Str]',
    required=>0,
);

__PACKAGE__->meta->make_immutable;
1;




__END__
=pod

=head1 NAME

Finance::HostedTrader::Config::DB - Finance::HostedTrader::Config::DB - DB Configuration for the Finance::HostedTrader platform

=head1 VERSION

version 0.001

=head1 SYNOPSIS

    use Finance::HostedTrader::Config::DB;
    my $obj = Finance::HostedTrader::Config::DB->new(
                    'dbhost'   => server_name,
                    'dbname'   => dbname,
                    'dbuser'   => dbuser,
                    'dbpasswd' => dbpasswd
                );

=head1 ATTRIBUTES

=head2 C<dbhost>

MySQL database server to connect to

=head2 C<dbname>

database name where data is stored

=head2 C<dbuser>

database user name used to connect

=head2 C<dbpasswd>

database password used to connect

=head1 SEE ALSO

L<Finance::HostedTrader::Config>

=head1 AUTHOR

João Costa <joaocosta@zonalivre.org>

=head1 COPYRIGHT AND LICENSE

This software is Copyright (c) 2012 by João Costa.

This is free software, licensed under:

  The MIT (X11) License

=cut

