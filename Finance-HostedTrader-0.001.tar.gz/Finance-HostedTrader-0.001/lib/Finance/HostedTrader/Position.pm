package Finance::HostedTrader::Position;

# ABSTRACT: Finance::HostedTrader::Position - Trade object


use strict;
use warnings;
use Moose;
use Moose::Util::TypeConstraints;

has symbol => (
    is     => 'ro',
    isa    => 'Str',
    required=>1,
);

has trades => (
    is     => 'ro',
    isa    => 'HashRef[Finance::HostedTrader::Trade]',
    builder => '_empty_hash',
    required=>0,
);

sub addTrade {
    my ($self, $trade) = @_;
    my $self_symbol = $self->symbol;
    my $self_trades = $self->trades;
    my $trade_symbol = $trade->symbol;
    my $trade_id = $trade->id;

    die("Trade has symbol " . $trade->symbol . " but position has symbol " . $self_symbol ) if ($self_symbol ne $trade_symbol);
    die("Trade already exists in position") if (exists($self_trades->{$trade_id}));
    $self_trades->{$trade_id} = $trade;
}

sub deleteTrade {
    my $self = shift;
    my $tradeID = shift;
    
    delete $self->trades->{$tradeID};    
}

sub getTrade {
    my $self = shift;
    my $id = shift;
    
    return $self->trades->{$id};
}

sub getOpenTradeList {
    my $self = shift;
    
    my @trades = values(%{$self->trades});
    return \@trades;
}

sub size {
    my ($self) = @_;

    my $size = 0;

    foreach my $trade (@{ $self->getOpenTradeList }) {
        $size += $trade->size();
    }

    return $size;
}

sub averagePrice {
    my ($self) = @_;
    
    my $size = 0;
    my $price = 0;

    foreach my $trade(@{ $self->getOpenTradeList }) {
        $size += $trade->size();
        $price += $trade->size() * $trade->openPrice();
    }

    return undef if ($size == 0);
    return $price / $size;
}

sub pl {
    my ($self, $system) = @_;
    my $pl=0;
    foreach my $trade (@{$self->getOpenTradeList}) {
        $pl += $trade->pl;
    }
    return $pl
}

sub _empty_hash {
    return {};
}

__PACKAGE__->meta->make_immutable;
1;


__END__
=pod

=head1 NAME

Finance::HostedTrader::Position - Finance::HostedTrader::Position - Trade object

=head1 VERSION

version 0.001

=head1 SYNOPSIS

    use Finance::HostedTrader::Position;
    my $obj = Finance::HostedTrader::Position->new(
                );

=head1 ATTRIBUTES

=head2 C<symbol>

=head2 C<trades>

=head1 METHODS

=head2 C<addTrade($trade)>

Adds the L<Finance::HostedTrader::Trade> object to this position.

Dies if another trade object with the same ID has already been added before
Dies if the symbol of $trade is different than the symbol of this position object instance

=head2 C<deleteTrade($id)>

=head2 C<getTrade($id)>

=head2 C<getOpenTradeList()>
    Returns a reference to a list of trades in this position.
    There is no particular order in the returned data.

=head2 C<size()>

Returns the aggregate size of all trades in this position.

Eg1:
  short 10000
  long  20000

  size = 10000

Eg2:
  short 10000
  short 10000

  size = -20000

=head2 C<averagePrice>

=head2 C<pl>

Calculate total profit/loss of a given position

=head1 SEE ALSO

L<Finance::HostedTrader::Trade>

=head1 AUTHOR

João Costa <joaocosta@zonalivre.org>

=head1 COPYRIGHT AND LICENSE

This software is Copyright (c) 2012 by João Costa.

This is free software, licensed under:

  The MIT (X11) License

=cut

