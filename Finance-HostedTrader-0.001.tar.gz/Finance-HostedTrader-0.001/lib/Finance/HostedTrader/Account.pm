package Finance::HostedTrader::Account;
# ABSTRACT: Finance::HostedTrader::Account - Account object



use strict;
use warnings;
use Moose;
use Finance::HostedTrader::ExpressionParser;
use Finance::HostedTrader::Position;

use Date::Manip;


##These should exist everywhere, regardless of broker

has startDate => (
    is     => 'rw',
    isa    => 'Str',
    required=>1,
    default => 'now',
);

has endDate => (
    is     => 'rw',
    isa    => 'Str',
    required=>1,
    default => '-10 years ago',
);

has 'notifier' => (
    is     => 'ro',
    isa    => 'Finance::HostedTrader::Trader::Notifier',
    required=>0,
);

has '_signal_processor' => (
    is      => 'ro',
    isa     => 'Finance::HostedTrader::ExpressionParser',
    lazy    => 1,
    builder => '_build_signal_processor',
);

sub _build_signal_processor {
    return Finance::HostedTrader::ExpressionParser->new();
}



sub BUILD {
    my $self = shift;

    my $startDate = UnixDate($self->startDate, '%Y-%m-%d %H:%M:%S');
    die("Invalid date format: " . $self->startDate) if (!$startDate);
    my $endDate = UnixDate($self->endDate, '%Y-%m-%d %H:%M:%S');
    die("Invalid date format: " . $self->endDate) if (!$endDate);
    die("End date cannot be earlier than start date") if ( $endDate lt $startDate);
    $self->startDate($startDate);
    $self->endDate($endDate);
    $self->{_positions} = {};
    $self->{_lastRefreshPositions} = 0;
}

sub refreshPositions {
    die("overrideme");
}

sub getAsk {
    die("overrideme");
}

sub getBid {
    die("overrideme");
}

sub openMarket {
    my ($self, $symbol, $direction, $amount, $stopLoss) = @_;
    my $trade = inner();
    
    if (!$trade) {
        die("openMarket did not return a trade object\nParameters were: $symbol $direction $amount $stopLoss");
    }
    
    my $notifier = $self->notifier();
    if ($notifier) {
        $notifier->open(
            symbol      => $symbol,
            direction   => $direction,
            amount      => $amount, 
            stopLoss    => $stopLoss,
            orderID     => $trade->id,
            rate        => $trade->openPrice,
            now         => $self->getServerDateTime(),
            nav         => $self->getNav(),
            balance     => $self->balance(),
        );
    }
    
    return $trade;
}

sub closeMarket {
    die("overrideme");
}

sub getBaseUnit {
    die("overrideme");
}

sub balance {
    die("overrideme");
}

sub getBaseCurrency {
    die("overrideme");
}

sub getServerEpoch {
    die("overrideme");
}

sub getServerDateTime {
    die("overrideme");
}

sub checkSignal {
    my ($self, $symbol, $signal_definition, $signal_args) = @_;

    return $self->_signal_processor->checkSignal(
        {
            'expr' => $signal_definition, 
            'symbol' => $symbol,
            'tf' => $signal_args->{timeframe},
            'maxLoadedItems' => $signal_args->{maxLoadedItems},
            'period' => $signal_args->{period},
            'debug' => $signal_args->{debug},
        }
    );
}

sub getIndicatorValue {
    my ($self, $symbol, $indicator, $args) = @_;

    my $value = $self->_signal_processor->getIndicatorData( {
                symbol  => $symbol,
                tf      => $args->{timeframe},
                fields  => 'datetime, ' . $indicator,
                maxLoadedItems => $args->{maxLoadedItems},
                numItems => 1,
                debug => $args->{debug},
    } );

    return $value->[0]->[1];
}

sub waitForNextTrade {
    my ($self, $system) = @_;

    die('overrideme');
}

#=method C<convertToBaseCurrency($amount, $currentCurrency, $bidask>
#
#Converts $amount from $currentCurrency to the account's base currency, using either 'bid' or 'ask' price.
#
#=cut
#sub convertToBaseCurrency {
#    my ($self, $amount, $currentCurrency, $bidask) = @_;
#    $bidask = 'ask' if (!$bidask);
#
#    my $baseCurrency = $self->getBaseCurrency();
#
#    return $amount if ($baseCurrency eq $currentCurrency);
#    my $pair = $baseCurrency . $currentCurrency;
#    if ($bidask eq 'ask') {
#        return $amount / $self->getAsk($pair);
#    } elsif ($bidask eq 'bid') {
#        return $amount / $self->getBid($pair);
#    } else {
#        die("Invalid value in bidask argument: '$bidask'");
#    }
#}

sub convertBaseUnit {
    my ($self, $symbol, $amount) = @_;
    my $baseUnit = $self->getBaseUnit($symbol);

    return int($amount / $baseUnit) * $baseUnit;
}

sub getPosition {
    my ($self, $symbol, $forceRefresh) = @_;

    my $positions = $self->getPositions($forceRefresh);
    return Finance::HostedTrader::Position->new(symbol=>$symbol) if (!defined($positions->{$symbol}));
    return $positions->{$symbol};
}

sub getPositions {
    my ($self, $forceRefresh) = @_;

    # Clients call getPositions() all the time to get list of current positions
    # Avoid going to the server every single time. This improves performance (less network traffic)
    # at a cost of the positions not being necessarly up to date (eg: a position might have been opened/closed via manual trading)
    # Also, this is necessary because some APIs limit the number of requests one can make. Eg: ForexConnect only allow this request
    # 50 time per hour.
    if ($forceRefresh || time() - $self->{_lastRefreshPositions} > 150) {
        $self->refreshPositions();
        $self->{_lastRefreshPositions} = time();
    }
    return $self->{_positions};
}

sub closeTrades {
    my ($self, $symbol, $directionToClose) = @_;

    my $posSize = 0;
    my $position = $self->getPosition($symbol,1);
    foreach my $trade (@{ $position->getOpenTradeList }) {
        my $trade_direction = $trade->direction;
        next if ($trade_direction ne $directionToClose);
        $self->closeMarket($trade->id, abs($trade->size));
        $posSize += $trade->size;
    }
    
    my $notifier = $self->notifier;
    if ($notifier) {
        my $value = ($directionToClose eq 'long' ? $self->getAsk($symbol) : $self->getBid($symbol) );
        $notifier->close(
            symbol      => $symbol,
            direction   => $directionToClose,
            amount      => $posSize, 
            currentValue=> $value,
            now         => $self->getServerDateTime(),
            nav         => $self->getNav(),
            balance     => $self->balance(),
        );
    }
}

sub pl {
    my $self = shift;
    my $pl = 0;

    my $positions = $self->getPositions();
    foreach my $symbol (keys %{$positions}) {
        my $position = $positions->{$symbol};
        $pl += $position->pl;
    }

    return $pl;
}

sub getNav {
    my $self = shift;

    return $self->balance() + $self->pl();
}

my %symbolBaseMap = (
    AUDCAD => 'CAD',
    AUDCHF => 'CHF',
    AUDJPY => 'JPY',
    AUDNZD => 'NZD',
    AUDUSD => 'USD',
    AUS200 => 'AUD',
    CADCHF => 'CHF',
    CADJPY => 'JPY',
    CHFJPY => 'JPY',
    CHFNOK => 'NOK',
    CHFSEK => 'SEK',
    EURAUD => 'AUD',
    EURCAD => 'CAD',
    EURCHF => 'CHF',
    EURDKK => 'DKK',
    EURGBP => 'GBP',
    EURJPY => 'JPY',
    EURNOK => 'NOK',
    EURNZD => 'NZD',
    EURSEK => 'SEK',
    EURTRY => 'TRY',
    EURUSD => 'USD',
    GBPAUD => 'AUD',
    GBPCAD => 'CAD',
    GBPCHF => 'CHF',
    GBPJPY => 'JPY',
    GBPNZD => 'NZD',
    GBPSEK => 'SEK',
    GBPUSD => 'USD',
    HKDJPY => 'JPY',
    NOKJPY => 'JPY',
    NZDCAD => 'CAD',
    NZDCHF => 'CHF',
    NZDJPY => 'JPY',
    NZDUSD => 'USD',
    SEKJPY => 'JPY',
    SGDJPY => 'JPY',
    TRYJPY => 'JPY',
    USDCAD => 'CAD',
    USDCHF => 'CHF',
    USDDKK => 'DKK',
    USDHKD => 'HKD',
    USDJPY => 'JPY',
    USDMXN => 'MXN',
    USDNOK => 'NOK',
    USDSEK => 'SEK',
    USDSGD => 'SGD',
    USDTRY => 'TRY',
    USDZAR => 'ZAR',
    XAGUSD => 'USD',
    XAUUSD => 'USD',
    ZARJPY => 'JPY',
    ESP35  => 'EUR',
    FRA40  => 'EUR',
    GER30  => 'EUR',
    HKG33  => 'HKD',
    ITA40  => 'EUR',
    JPN225 => 'JPY',
    NAS100 => 'USD',
    SPX500 => 'USD',
    SUI30  => 'CHF',
    SWE30  => 'SEK',
    UK100  => 'GBP',
    UKOil  => 'GBP',
    US30   => 'USD',
    USOil  => 'USD',
);

sub getSymbolBase {
    my ($self, $symbol) = @_;

    die("Unsupported symbol '$symbol'") if (!exists($symbolBaseMap{$symbol}));
    return $symbolBaseMap{$symbol};
}

__PACKAGE__->meta->make_immutable;
1;


__END__
=pod

=head1 NAME

Finance::HostedTrader::Account - Finance::HostedTrader::Account - Account object

=head1 VERSION

version 0.001

=head1 SYNOPSIS

    use Finance::HostedTrader::Account;
    my $obj = Finance::HostedTrader::Account->new(
                );

=head1 ATTRIBUTES

=head2 C<startDate>

The time the trading system starts trading

=head2 C<endDate>

The time the trading system stops trading

=head2 C<notifier>

=head1 METHODS

=head2 C<BUILD>

Constructor.

Converts {start,end}Date to 'YYYY-MM-DD hh:mm:ss' format using L<Date::Manip> UnixDate.

Validates dates.

=head2 C<refreshPositions()>

This method must be overriden. It updates $self->{_positions} with an hash ref keyed by symbol with a L<Finance::HostedTrader::Position> object as value.

This method will typically have to read existing positions from the Account provider (eg: L<Finance::HostedTrader::Account::FXCM::ForexConnect>)
and store them in the Account object for local access.

It gets called by getPosition and getPositions

=head2 C<getAsk($symbol)>

This method must be overriden. Returns the current ask price for $symbol.

=head2 C<getBid>

This method must be overriden. Returns the current bid price for $symbol.

=head2 C<openMarket($symbol, $direction, $amount>

This method must be overriden. Opens a trade in $symbol at current market price.

$direction can be either 'long' or 'short'

Returns a list containing two elements:

$tradeID - This can be passed to closeMarket. It can also be retrieved via getTrades
$price   - The price at which the trade was executed.

If a notifier has been defined, the L<Finance::HostedTrader::Notifier> open method is called after the trade is open.

=head2 C<closeMarket($tradeID, $amount)>

This method must be overriden. Closes a trade at current market price.

$tradeID is returned when calling openMarket(). It can also be retrieved via getTrades().

Returns $closedTradeID

=head2 C<getBaseUnit($symbol)>

This method must be overriden. Returns the base unit at which the symbol trades.

Eg, if baseUnit=10000, the symbol can only trade in multiples of 10000 (15000 would be an invalid trade size).

=head2 C<balance()>

This method must be overriden to return the current balance in the account ( before p/l of open positions )

=head2 C<getBaseCurrency()>

This method must be overriden. Returns the currency in which funds are held in this account. Useful to calculate profit/loss.

=head2 C<getServerEpoch()>

This method must be overriden. Returns the current unix epoch time on the account server.

=head2 C<getServerDateTime()>

This method must be overriden. Returns the current date/time on the account server in '%Y-%m-%d %H:%M:%S' format.

=head2 C<checkSignal($symbol, $signal, $args)>

Returns true if the given $signal/$args occurs in $symbol

=head2 C<getIndicatorValue($symbol, $indicator, $args)>

Returns the indicator value of $indicator/$args on $symbol.

=head2 C<waitForNextTrade($system)>

=head2 C<convertBaseUnit($symbol, $amount)>

Convert $amount to the base unit supported by $symbol.

See the L</getBaseUnit($symbol)> method.

=head2 C<getPosition($symbol)>

Returns a L<Finance::HostedTrader::Position> object for $symbol.

This object will contain information about all open trades in $symbol.

=head2 C<getPositions()>

Returns a hashref whose key is a "trading symbol" and value a L<Finance::HostedTrader::Position> object for that symbol.

=head2 C<closeTrades($symbol,$direction)>

Closes all trades in the given $symbol/$direction at market.

=head2 C<pl()>

Profit/Loss for currently open positions

=head2 C<getNav()>

Returns current Net Asset Value ( including p/l of open positions )

=head2 C<getSymbolBase($symbol)>

Returns the base currency for a symbol, useful for calculating profit/loss.

Eg:
 US Stocks => 'USD'
 EURUSD => 'USD'
 USDCHF => 'CHF'

=head1 SEE ALSO

L<Finance::HostedTrader::Factory::Account>
L<Finance::HostedTrader::Position>

=head1 AUTHOR

João Costa <joaocosta@zonalivre.org>

=head1 COPYRIGHT AND LICENSE

This software is Copyright (c) 2012 by João Costa.

This is free software, licensed under:

  The MIT (X11) License

=cut

