package Finance::HostedTrader::Factory::Notifier;
# ABSTRACT: Finance::HostedTrader::Factory::Notifier - Interface to the Factory broker


use Moose;

use Moose::Util::TypeConstraints;

has [qw(SUBCLASS)] => ( is => 'ro', required => 1);


sub BUILD {
    my $self = shift;
    my $args = shift;

    delete $args->{SUBCLASS};
    $self->{_args} = $args;
}


sub create_instance {
my $self = shift;

    my $sc = $self->SUBCLASS();

    if ($sc eq 'Production') {
        require Finance::HostedTrader::Trader::Notifier::Production;
        return Finance::HostedTrader::Trader::Notifier::Production->new( $self->{_args} );
    } elsif ($sc eq 'UnitTest') {
        require Finance::HostedTrader::Trader::Notifier::UnitTest;
        return Finance::HostedTrader::Trader::Notifier::UnitTest->new( $self->{_args} );
    } else {
        die("Don't know about Notifier class: $sc");
    }
}


__PACKAGE__->meta->make_immutable;

1;



__END__
=pod

=head1 NAME

Finance::HostedTrader::Factory::Notifier - Finance::HostedTrader::Factory::Notifier - Interface to the Factory broker

=head1 VERSION

version 0.001

=head1 SYNOPSIS

    use Finance::HostedTrader::Factory::Notifier;

    my $account = Finance::HostedTrader::Factory::Notifier->new(
                        SUBCLASS    => 'Production',
                  )->create_instance();

    my $test = Finance::HostedTrader::Factory::Notifier->new(
                        SUBCLASS    => 'UnitTest',
                  )->create_instance();

=head1 ATTRIBUTES

=head2 C<SUBCLASS>

Readonly. Required.

The type of account to instantiate.

Supported values are:
    - Production
    - UnitTest

=head1 METHODS

=head2 C<BUILD>

The constructor takes all arguments passed onto Factory::Notifier
and passes them to the target class defined by SUBCLASS.

=head2 C<create_instance()>

Return an account instance of type SUBCLASS

=head1 SEE ALSO

=over 4

=item *

L<Finance::HostedTrader::Notifier>,

=item *

L<Finance::HostedTrader::Notifier::Production>

=item *

L<Finance::HostedTrader::Notifier::UnitTest>

=back

=head1 AUTHOR

João Costa <joaocosta@zonalivre.org>

=head1 COPYRIGHT AND LICENSE

This software is Copyright (c) 2012 by João Costa.

This is free software, licensed under:

  The MIT (X11) License

=cut

