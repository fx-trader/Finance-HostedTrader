package Finance::HostedTrader::Trader::Notifier;
# ABSTRACT: Finance::HostedTrader::Notifier - Notifier object



use strict;
use warnings;

use Moose;
use Params::Validate qw(:all);
use Scalar::Util;


sub _isPositiveNum {
    my $value = shift;
    return Scalar::Util::looks_like_number($value) && $value > 0;    
}

sub _isDirection {
    my $value = shift;
    return $value eq 'long' || $value eq 'short';
}

around 'open' => sub {
    my $orig = shift;
    my $self = shift;

    validate( @_,
              {
                symbol      =>  { type => SCALAR },
                direction   =>  { type => SCALAR, callbacks => { v => \&_isDirection } },
                amount      =>  { type => SCALAR, regex => qr/^\d+$/ },
                stopLoss    =>  { type => SCALAR, callbacks => { v => \&_isPositiveNum } },
                orderID     =>  { type => SCALAR },
                rate        =>  { type => SCALAR, callbacks => { v => \&_isPositiveNum } },
                now         =>  { type => SCALAR },
                nav         =>  { type => SCALAR, callbacks => { v => \&_isPositiveNum } },
                balance     =>  { type => SCALAR, callbacks => { v => \&_isPositiveNum } },
              }
            );
    $self->$orig(@_);
};

sub open {
    die("overrideme");
}


around 'close' => sub {
    my $orig = shift;
    my $self = shift;

    validate( @_,
              {
                symbol      =>  { type => SCALAR },
                direction   =>  { type => SCALAR, callbacks => { v => \&_isDirection } },
                amount      =>  { type => SCALAR, regex => qr/^\d+$/ },
                currentValue=>  { type => SCALAR, callbacks => { v => \&_isPositiveNum } },
                now         =>  { type => SCALAR },
                nav         =>  { type => SCALAR, callbacks => { v => \&_isPositiveNum } },
                balance     =>  { type => SCALAR, callbacks => { v => \&_isPositiveNum } },
              }
            );
    $self->$orig(@_);
};

sub close {
    die("overrideme");
}


__PACKAGE__->meta->make_immutable;
1;


__END__
=pod

=head1 NAME

Finance::HostedTrader::Trader::Notifier - Finance::HostedTrader::Notifier - Notifier object

=head1 VERSION

version 0.001

=head1 SYNOPSIS

    use Finance::HostedTrader::Notifier;
    my $obj = Finance::HostedTrader::Notifier->new(
                );

=head1 METHODS

=head2 C<open()>

=head2 C<close()>

=head1 SEE ALSO

L<Finance::HostedTrader::Trader>

=head1 AUTHOR

João Costa <joaocosta@zonalivre.org>

=head1 COPYRIGHT AND LICENSE

This software is Copyright (c) 2012 by João Costa.

This is free software, licensed under:

  The MIT (X11) License

=cut

