package Finance::HostedTrader::Trader::Notifier::Production;
# ABSTRACT: Finance::HostedTrader::Notifier - Notifier object



use strict;
use warnings;

use Moose;
extends 'Finance::HostedTrader::Trader::Notifier';
use MIME::Lite;

sub open {
    my $self = shift;
    my %args=@_;

    my $symbol      = $args{symbol};
    my $direction   = $args{direction};
    my $amount      = $args{amount};
    my $stopLoss    = $args{stopLoss};
    my $orderID     = $args{orderID};
    my $rate        = $args{rate};
    

    $self->_sendMail('Trading Robot - Open Trade ' . $symbol, qq {Open Trade:
Instrument: $symbol
Amount: $amount
Open Price: $rate
Stop Loss: $stopLoss
            });
}

sub close {
    my $self = shift;
    my %args=@_;

    my $symbol      = $args{symbol};
    my $direction   = $args{direction};
    my $amount      = $args{amount};
    my $value       = $args{currentValue};
    
    $self->_sendMail('Trading Robot - Close Trade ' . $symbol, qq {Close Trade:
Instrument: $symbol
Direction: $direction
Position Size: $amount
Current Value: $value
    });
}

sub _sendMail {
my ($self, $subject, $content) = @_;
use MIME::Lite;

    #$self->logger($content);
    ### Create a new single-part message, to send a GIF file:
    my $msg = MIME::Lite->new(
        From     => 'fxhistor@fxhistoricaldata.com',
        To       => 'joaocosta@zonalivre.org', #TODO: Hardcoded, needs to be parameterized as a class attribute
        Subject  => $subject,
        Data     => $content
    );
    $msg->send; # send via default
}

__PACKAGE__->meta->make_immutable;
1;

__END__
=pod

=head1 NAME

Finance::HostedTrader::Trader::Notifier::Production - Finance::HostedTrader::Notifier - Notifier object

=head1 VERSION

version 0.001

=head1 SYNOPSIS

    use Finance::HostedTrader::Notifier::Production;
    my $obj = Finance::HostedTrader::Notifier::Production->new(
                );

=head1 METHODS

=head2 C<open($trade)>

open trade notifier. Receives a L<Finance::HostedTrader::Trade> object representing the trade that was opened.

Sends an email with information about the trade.

=head2 C<close()>

=head1 AUTHOR

João Costa <joaocosta@zonalivre.org>

=head1 COPYRIGHT AND LICENSE

This software is Copyright (c) 2012 by João Costa.

This is free software, licensed under:

  The MIT (X11) License

=cut

