package Finance::HostedTrader;
# ABSTRACT: Finance::HostedTrader - Framework for testing and running trading systems


use strict;
use warnings;

1;

__END__
=pod

=head1 NAME

Finance::HostedTrader - Finance::HostedTrader - Framework for testing and running trading systems

=head1 VERSION

version 0.001

=head1 SYNOPSIS

=head1 AUTHOR

João Costa <joaocosta@zonalivre.org>

=head1 COPYRIGHT AND LICENSE

This software is Copyright (c) 2012 by João Costa.

This is free software, licensed under:

  The MIT (X11) License

=cut

